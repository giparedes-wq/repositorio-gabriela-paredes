# GABRIELA_PAREDES

A Pen created on CodePen.

Original URL: [https://codepen.io/GABRIELA-ITZEL-PAREDESVELES/pen/yyebdVJ](https://codepen.io/GABRIELA-ITZEL-PAREDESVELES/pen/yyebdVJ).

